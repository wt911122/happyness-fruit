var MockItemData = [
	{
		id: 1,
		imgURL: "app/style/images/colorful.png",
		imgURLActive: "app/style/images/colorful_active.png",
		item: 
	},
	{
		id: 2,
		imgURL: "app/style/images/double.png",
		imgURLActive: "app/style/images/double_active.png"
	},
	{
		id: 3,
		imgURL: "app/style/images/probiotics.gif",
		imgURLActive: "app/style/images/probiotics_active.png"
	},
	{
		id: 4,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 5,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 6,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 7,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 8,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 11,
		imgURL: "app/style/images/colorful.png",
		imgURLActive: "app/style/images/colorful_active.png",
		item: 
	},
	{
		id: 12,
		imgURL: "app/style/images/double.png",
		imgURLActive: "app/style/images/double_active.png"
	},
	{
		id: 13,
		imgURL: "app/style/images/probiotics.gif",
		imgURLActive: "app/style/images/probiotics_active.png"
	},
	{
		id: 14,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 15,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 16,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 17,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	},
	{
		id: 18,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	}
]
module.exports = MockTypeData;