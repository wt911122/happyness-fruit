var CSSPrefixMixin = {
	addPrefix: function(whatever){
		return {
		}
}
module.exports = CSSPrefixMixin;