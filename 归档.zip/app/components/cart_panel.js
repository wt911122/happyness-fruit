var React = require("React");

var CartPanel = React.creatClass({
	render: function(){
		return (
			<div className="shadowCover">
				<div className="cart-panel">
					<div className="cart-header">
						
					</div>
				</div>
			</div>
			)
	}
});

module.exports = CartPanel;