var MockItemData = [
	{
		id: 1,
		imgURL: "app/style/images/colorful.png",
		imgURLActive: "app/style/images/colorful_active.png",
		item: 
	},
	{
		id: 2,
		imgURL: "app/style/images/double.png",
		imgURLActive: "app/style/images/double_active.png"
	},
	{
		id: 3,
		imgURL: "app/style/images/probiotics.gif",
		imgURLActive: "app/style/images/probiotics_active.png"
	},
	{
		id: 4,
		imgURL: "app/style/images/yogurt.gif",
		imgURLActive: "app/style/images/yogurt_active.png"
	}
]
module.exports = MockTypeData;