module.exports = {
	/* 组件通知 */
	ALTER_AD: "alterAd",
	TOGGLE_SIDEBAR: "toggle_sidebar",
	CALL_FOR_MODAL: "call_for_modal",
	GO_CHECK_CART: "go_check_cart",
	CALL_FOR_SHADOW: "call_for_shadow",
	ALTER_CART_ITEM: "alter_cart_item",
	CLOSE_SHADOW: "close_shadow",
	SHADOW_ON_CLOSE: "shadow_on_close",

	/* 异步获取action */
 	REQUST_AD: "requst_ad",	
 	REQUST_DATA: "requst_data"
}
