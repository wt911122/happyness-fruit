var IconType = [
	{
		id: 1,
		name: "西瓜",
		color: "#cc0311",
		backgroundColor: "#22ac38"
	},
	{
		id: 2,
		name: "石榴",
		color: "#fff",
		backgroundColor: "#cc0311"
	},
	{
		id: 3,
		name: "凤梨",
		color: "#fdf7b8",
		backgroundColor: "#80c269"
	},
	{
		id: 4,
		name: "葡萄",
		color: "#fff",
		backgroundColor: "#601986"
	},
	{
		id: 5,
		name: "芒果",
		color: "#fb0808",
		backgroundColor: "#fcc008"
	},
		{
		id: 6,
		name: "芒果",
		color: "#fb0808",
		backgroundColor: "#fcc008"
	},
		{
		id: 7,
		name: "芒果",
		color: "#fb0808",
		backgroundColor: "#fcc008"
	},
		{
		id: 8,
		name: "芒果",
		color: "#fb0808",
		backgroundColor: "#fcc008"
	},
];
module.exports = IconType;